/**
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; under version 2
 * of the License (non-upgradable).
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * Copyright (c) 2014 (original work) Open Assessment Technologies SA;
 */

/**
 * Define the Item Element Renderer
 */
import tpl from 'taoQtiItem/qtiCommonRenderer/tpl/item';
import containerHelper from 'taoQtiItem/qtiCommonRenderer/helpers/container';
import itemStylesheetHandler from 'taoQtiItem/qtiCommonRenderer/helpers/itemStylesheetHandler';

export default {
    qtiClass: 'assessmentItem',
    template: tpl,
    getContainer: containerHelper.get,

    /**
     * Rendering initializations for the item
     * @param {Object} item - the item model
     */
    render: function render(item) {
        //target blank for all <a>
        containerHelper.targetBlank(containerHelper.get(item));

        //add stylesheets
        itemStylesheetHandler.attach(item.stylesheets);
    },

    /**
     * Unrender
     * @param {Object} item - the item model
     */
    destroy: function destroy(item) {
        //clear the container cache
        containerHelper.clear();

        //detach stylesheets
        if (item.stylesheets) {
            itemStylesheetHandler.detach(item.stylesheets);
        }
    }
};
