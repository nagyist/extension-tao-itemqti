import Mixin from 'taoQtiItem/qtiItem/mixin/Mixin';
import Container from 'taoQtiItem/qtiItem/core/Container';

var methods = {
    initContainer: function(body) {
        this.bdy = new Container(body || '');
        this.bdy.setRootElement(this.getRootElement() || null);
        this.bdy.contentModel = 'blockStatic';
    },
    getBody: function() {
        return this.bdy;
    },
    body: function(body) {
        var ret = this.bdy.body(body);
        return body ? this : ret; //for method chaining on get
    },
    setElement: function(element, body) {
        this.bdy.setElement(element, body);
        return this;
    },
    removeElement: function(element) {
        return this.bdy.removeElement(element);
    },
    getElements: function(qtiClass) {
        return this.bdy.getElements(qtiClass);
    },
    getElement: function(serial) {
        return this.bdy.getElement(serial);
    }
};

export default {
    augment: function(targetClass) {
        Mixin.augment(targetClass, methods);
    },
    methods: methods
};
